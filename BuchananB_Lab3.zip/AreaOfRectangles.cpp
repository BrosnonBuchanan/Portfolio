// AreaOfRectangles.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{// declare variables
    int length, width, area;
    int length2, width2, area2;

    //user needs to put a space between the two numbers
    cout << "what is the length and width of the rectangle?" << endl;
    cin >> length;
    cin >> width;

    area = length * width;

    cout << "what is the length and width of the second rectangle?" << endl;
    cin >> length2;
    cin >> width2;

    area2 = length2 * width2;

    if (area > area2)
        cout << "The first rectangle has a bigger area. We're gonna need a bigger boat!" << endl;
    else
        cout << "The second rectangle has a bigger area. Look at the size of that one!" << endl;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
